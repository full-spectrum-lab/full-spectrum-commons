import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]

class ContractTests(unittest.TestCase):
    def test_server_requires_client_certificate(self):
        self.assertIn('CERT_REQUIRED', (ROOT / 'server/server.py').read_text())

    def test_client_enables_hostname_check(self):
        self.assertIn('check_hostname = True', (ROOT / 'client/client.py').read_text())

    def test_client_validates_node_id(self):
        src = (ROOT / 'client/client.py').read_text()
        self.assertIn('def validate_reply', src)
        self.assertIn('invalid server node identity', src)
        self.assertIn("node_id", src)

    def test_external_material_not_packaged(self):
        self.assertFalse(any(p.suffix in {'.pem', '.key'} for p in ROOT.rglob('*') if p.is_file()))

if __name__ == '__main__':
    unittest.main()
