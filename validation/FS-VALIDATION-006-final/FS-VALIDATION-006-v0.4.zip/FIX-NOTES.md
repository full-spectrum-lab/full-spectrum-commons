# FS-VALIDATION-006 v0.4 修复说明 — F-C / R11（应用层 node_id 未校验）

## 缺陷来源

v0.3 第一台主机拒绝测试（报告 `FS-VALIDATION-006-v0.3-第一台主机拒绝测试报告-2026-09-04.md`）发现：

- **R11（篡改 node_id）结果为 FAIL**：客户端接受了伪造的 `reply.node_id`（如 `ATTACKER_IMPERSONATOR`）。
- 根因（F-C）：`pkg/client/client.py` 的回执校验仅检查 `request_id` 回显与 `ack`，**从不校验 `reply.node_id`**。服务端固定回 `node_id: "server"`，对客户端无任何约束力，伪造节点身份即可通过应用层校验。

## 修复内容（v0.4）

文件：`pkg/client/client.py`

1. 新增常量 `EXPECTED_SERVER_NODE_ID = "server"`（由协议固定；注释明确禁止取自服务端回执本身）。
2. 新增 `validate_reply(reply, request_id)`，按 fail-closed 顺序校验：
   - `reply` 必须为 dict（非法 JSON / 空行先由 `json.loads` 拒绝）；
   - `reply.get("request_id") == request_id`；
   - `reply.get("node_id") == EXPECTED_SERVER_NODE_ID`；  ← **新增**
   - `reply.get("ack") == "ACCEPTED"`。
   - 任一不符抛 `ValueError`。
3. `main()` 在读取回执后调用 `validate_reply(reply, req)`，并把结果输出增加 `"node_identity": "VERIFIED"`。

`server.py` 保持不变（其回执已含 `node_id: "server"`，与期望值一致）。

## 验证

- 纯单元测试 `tests/test_validation.py`：8/8 通过，覆盖正常、篡改 request_id、篡改 node_id、篡改 ack、非法 JSON、缺失 node_id、缺失 request_id、缺失 ack。
- 全场景 `tests/test_reject_suite.py`（真实 TLS/mTLS，第一台持有 server.key）：**16/16 PASS**，含：
  - HAPPY：正常 mTLS + 正确回执 → 接受（PASS）；
  - R11：篡改 node_id → 客户端以 `invalid server node identity` 拒绝（PASS，修复点实锤）；
  - R01–R10、R12–R15：错误 CA / 过期证书 / key 不匹配 / 错主机名 / 缺客户端证书 / 缺 CA / 服务端 key 不匹配 / 非法 JSON / 非法 ack / 篡改 request_id / 服务端停止 / 端口关闭 / 超时 / 不可达 → 全部 fail-closed（PASS）。

## 未变更与未授权事项

- 未修改、未重新打包 `FS-VALIDATION-006-v0.3.zip` 及其哈希。
- 未提交/推送/打标签/发布/部署。
- 私钥 `server.key` 未进入 v0.4 ZIP，也未上传任何仓库/聊天/网盘。
- 证书为测试 CA 签发，时效约至 2026-09-06 13:09 GMT+8；后续测试须在此窗口内完成，逾期需重新签发并正式记录 `KEY_ROTATION_EXECUTED`。
