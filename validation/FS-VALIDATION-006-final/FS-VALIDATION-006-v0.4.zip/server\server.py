import argparse, json, ssl, socket

def main():
    p=argparse.ArgumentParser(); p.add_argument('--bind',default='0.0.0.0'); p.add_argument('--port',type=int,required=True); p.add_argument('--ca',required=True); p.add_argument('--cert',required=True); p.add_argument('--key',required=True); args=p.parse_args()
    ctx=ssl.create_default_context(ssl.Purpose.CLIENT_AUTH, cafile=args.ca); ctx.load_cert_chain(args.cert,args.key); ctx.verify_mode=ssl.CERT_REQUIRED
    with socket.create_server((args.bind,args.port)) as raw:
        with ctx.wrap_socket(raw,server_side=True) as listener:
            conn,_=listener.accept()
            with conn:
                msg=json.loads(conn.makefile().readline()); reply={'request_id':msg['request_id'],'node_id':'server','ack':'ACCEPTED'}
                conn.sendall((json.dumps(reply)+'\n').encode())
if __name__=='__main__': main()
