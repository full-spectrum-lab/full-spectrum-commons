"""v0.4 回归测试：服务端回执校验（纯单元，无需证书/TLS）。

直接加载 client/client.py 源码并测试 validate_reply()，覆盖：
- 正常回执通过；
- 篡改 request_id 被拒绝；
- 篡改 node_id 被拒绝（修复 F-C / R11）；
- 篡改 ack 被拒绝；
- 非法 JSON（非 dict）被拒绝；
- 缺失 node_id 被拒绝；
- 缺失 request_id 被拒绝；
- 缺失 ack 被拒绝。

运行：python pkg/tests/test_validation.py
"""
import importlib.util, os, sys, unittest

_CLIENT = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'client', 'client.py')
_spec = importlib.util.spec_from_file_location('v04_client', _CLIENT)
_client_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_client_mod)
validate_reply = _client_mod.validate_reply


class TestValidateReply(unittest.TestCase):
    def _reply(self, **over):
        r = {"request_id": "R1", "node_id": "server", "ack": "ACCEPTED"}
        r.update(over)
        return r

    def test_normal_pass(self):
        validate_reply(self._reply(), "R1")  # 不应抛异常

    def test_tamper_request_id(self):
        with self.assertRaises(ValueError):
            validate_reply(self._reply(request_id="WRONG"), "R1")

    def test_tamper_node_id(self):
        with self.assertRaises(ValueError):
            validate_reply(self._reply(node_id="ATTACKER_IMPERSONATOR"), "R1")

    def test_tamper_ack(self):
        with self.assertRaises(ValueError):
            validate_reply(self._reply(ack="REJECTED"), "R1")

    def test_invalid_json_non_dict(self):
        with self.assertRaises(ValueError):
            validate_reply("not a dict", "R1")

    def test_missing_node_id(self):
        with self.assertRaises(ValueError):
            validate_reply({"request_id": "R1", "ack": "ACCEPTED"}, "R1")

    def test_missing_request_id(self):
        with self.assertRaises(ValueError):
            validate_reply({"node_id": "server", "ack": "ACCEPTED"}, "R1")

    def test_missing_ack(self):
        with self.assertRaises(ValueError):
            validate_reply({"request_id": "R1", "node_id": "server"}, "R1")


if __name__ == '__main__':
    unittest.main(verbosity=2)
