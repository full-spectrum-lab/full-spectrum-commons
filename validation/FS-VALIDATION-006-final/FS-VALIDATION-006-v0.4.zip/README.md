# FS-VALIDATION-006 v0.4 — 双主机 TLS/mTLS 运行包（node_id 校验修复）

第一台主机运行 `server/server.py`，第二台主机运行 `client/client.py`。双方使用外部提供的 CA、证书和私钥完成双向 TLS 握手；v0.4 起，客户端**额外强制校验服务端应用层身份** `reply.node_id == 'server'`，以修复 v0.3 拒绝测试发现的 F-C / R11 缺陷。

状态：`EXPERIMENTAL` / `CROSS_HOST_TLS_MTLS_RUNTIME` / `PRODUCTION_READY = NO`。

## 相对 v0.3 的变更

- **修复 F-C / R11**：`client/client.py` 新增 `validate_reply(reply, request_id)`，强制校验三字段：
  - `reply.request_id == request_id`（回显一致）
  - `reply.node_id == EXPECTED_SERVER_NODE_ID`（常量 `"server"`，**修复点**：此前缺失，导致伪造节点身份被接受）
  - `reply.ack == "ACCEPTED"`
  - 任一不符即抛 `ValueError`（fail-closed）。
- `server.py` **未改动**（服务端仍回 `node_id: "server"`）。
- 新增回归测试：`tests/test_validation.py`（纯单元，无需证书，任意机器可跑）、`tests/test_reject_suite.py`（happy path + 15 拒绝场景，需 `server.key`，仅第一台可跑）。

## 证书与私钥

证书和私钥**不包含在 ZIP 中**。请使用测试 CA 签发的临时证书，并通过参数传入路径。请勿将 `server.key` 传出第一台。

## 运行

第一台（TLS Server）：

```powershell
python server/server.py --bind 0.0.0.0 --port 39124 --ca ca.pem --cert server.pem --key server.key
```

第二台（TLS Client）：

```powershell
python client/client.py --host 192.168.110.115 --port 39124 --server-name 192.168.110.115 --ca ca.pem --cert client.pem --key client.key
```

> 服务端为单连接模型：每次仅接受一个客户端连接，连接后退出。跨主机每测一项前需第一台重启服务端。第二台应**直接 TLS 连接**，勿用裸 TCP 探针。

## 测试

```bash
# 纯单元（任意机器，无需证书）
python pkg/tests/test_validation.py

# 全场景（需 FV006_CERTS_DIR 指向含 server.key 的证书目录，仅第一台）
FV006_CERTS_DIR=/path/to/certs python pkg/tests/test_reject_suite.py
```

## 边界声明

本版本仅修复应用层 `node_id` 校验。即便通过本地与本机回环验证，**未经第二台真实跨主机独立复核前**，不得声称 Full Spectrum 治理互操作性已证明，也不得声称生产就绪。`overall` 保持 `UNKNOWN`，`PRODUCTION_READY = NO`。
