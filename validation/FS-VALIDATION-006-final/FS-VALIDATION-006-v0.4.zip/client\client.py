import argparse, json, ssl, socket, uuid

# 期望的服务端应用层身份（由协议固定；此处为常量，防止任意伪造的 node_id 被接受）。
# 若未来协议改为配置化身份，请从受信任的配置源读取，绝不可取自服务端回执本身。
EXPECTED_SERVER_NODE_ID = "server"

def validate_reply(reply, request_id):
    """校验服务端回执。任一字段不符即抛出 ValueError（fail-closed）。

    - reply 必须是 dict（非法 JSON / 空行会先被 json.loads 拒绝）
    - request_id 必须回显为本次请求值
    - node_id 必须等于期望的服务端身份（修复 F-C / R11：此前缺失此校验）
    - ack 必须为 ACCEPTED
    """
    if not isinstance(reply, dict):
        raise ValueError("invalid server reply: not a JSON object")
    if reply.get("request_id") != request_id:
        raise ValueError("invalid request id")
    if reply.get("node_id") != EXPECTED_SERVER_NODE_ID:
        raise ValueError("invalid server node identity")
    if reply.get("ack") != "ACCEPTED":
        raise ValueError("invalid server acknowledgement")

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--host', required=True)
    p.add_argument('--port', type=int, required=True)
    p.add_argument('--server-name', required=True)
    p.add_argument('--ca', required=True)
    p.add_argument('--cert', required=True)
    p.add_argument('--key', required=True)
    args = p.parse_args()
    ctx = ssl.create_default_context(ssl.Purpose.SERVER_AUTH, cafile=args.ca)
    ctx.load_cert_chain(args.cert, args.key)
    ctx.check_hostname = True
    req = str(uuid.uuid4())
    msg = {'request_id': req, 'node_id': 'client',
           'governance_fact': {'knowledge_version': 'v1', 'authorization': 'recommendation'}}
    with socket.create_connection((args.host, args.port), timeout=10) as raw:
        with ctx.wrap_socket(raw, server_hostname=args.server_name) as conn:
            conn.sendall((json.dumps(msg) + '\n').encode())
            reply = json.loads(conn.makefile().readline())
    validate_reply(reply, req)
    print(json.dumps({'tls_handshake': 'PASS', 'mutual_auth': 'PASS',
                      'node_identity': 'VERIFIED', 'overall': 'UNKNOWN', 'production_ready': 'NO'}))

if __name__ == '__main__':
    main()
