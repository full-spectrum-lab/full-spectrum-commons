"""v0.4 全场景验证套件（需 FV006_CERTS_DIR 环境变量指向含测试证书/私钥的目录）。

第一台主机（持有 server.key）运行此脚本，使用真实 server.py 与 v0.4 client.py，
对 1 个 happy path + 15 个拒绝场景执行真实 TLS/mTLS 握手并判定 fail-closed。

场景列表：
  HAPPY            正常 mTLS + 正确回执 -> 接受
  R01 错误 CA
  R02 过期客户端证书
  R03 客户端证书/私钥不匹配
  R04 错误服务端主机名
  R05 缺少客户端证书
  R06 缺少/无效 CA
  R07 服务端证书/私钥不匹配
  R08 非法 JSON 回执
  R09 非法 ack 回执
  R10 篡改 request_id 回执
  R11 篡改 node_id 回执   <-- 修复点，必须从 FAIL 变 PASS
  R12 服务端停止
  R13 端口关闭
  R14 连接超时/无响应
  R15 对端不可达

用法：FV006_CERTS_DIR=/path/to/certs python pkg/tests/test_reject_suite.py
"""
import json, os, socket, ssl, subprocess, sys, threading, time, traceback

PY = sys.executable
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CLIENT = os.path.join(ROOT, 'client', 'client.py')
SERVER = os.path.join(ROOT, 'server', 'server.py')
CERTS = os.environ.get('FV006_CERTS_DIR')
OUTDIR = os.path.join(os.path.dirname(ROOT), 'reject_evidence_v04')
os.makedirs(OUTDIR, exist_ok=True)


def free_port():
    s = socket.socket()
    s.bind(('127.0.0.1', 0))
    p = s.getsockname()[1]
    s.close()
    return p


def start_real_server(port, key=None):
    cmd = [PY, SERVER, '--bind', '127.0.0.1', '--port', str(port),
           '--ca', os.path.join(CERTS, 'ca.pem'),
           '--cert', os.path.join(CERTS, 'server.pem'),
           '--key', key or os.path.join(CERTS, 'server.key')]
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    time.sleep(0.6)
    return p


def reap(srv, t=5):
    """终止并回收服务端子进程；若已自行退出则直接取退出码。避免 wait 卡死。"""
    if srv.poll() is None:
        try:
            srv.terminate()
        except Exception:
            pass
    try:
        return srv.wait(timeout=t)
    except Exception:
        return None


class TamperServer(threading.Thread):
    """呈现合法服务端证书（mTLS 握手成功），随后发送篡改的回执。

    echo_request_id=True 时，会先解析客户端请求并原样回显其 request_id，
    从而把拒绝原因精确锁定在目标字段（如 node_id / ack），而非 request_id。
    """

    def __init__(self, port, reply, echo_request_id=True):
        super().__init__(daemon=True)
        self.port = port
        self.reply = reply
        self.echo_request_id = echo_request_id
        self.ctx = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH,
                                              cafile=os.path.join(CERTS, 'ca.pem'))
        self.ctx.load_cert_chain(os.path.join(CERTS, 'server.pem'),
                                 os.path.join(CERTS, 'server.key'))
        self.ctx.verify_mode = ssl.CERT_REQUIRED

    def run(self):
        try:
            with socket.create_server(('127.0.0.1', self.port)) as raw:
                with self.ctx.wrap_socket(raw, server_side=True) as tls:
                    conn, _ = tls.accept()
                    with conn:
                        line = conn.makefile().readline()
                        if self.echo_request_id and isinstance(self.reply, dict):
                            try:
                                rid = json.loads(line).get('request_id')
                                self.reply = dict(self.reply)
                                self.reply['request_id'] = rid
                            except Exception:
                                pass
                        conn.sendall((json.dumps(self.reply) + '\n').encode())
        except Exception:
            pass


class HangServer(threading.Thread):
    """接受连接后立刻关闭（模拟无响应/超时）。"""

    def __init__(self, port):
        super().__init__(daemon=True)
        self.port = port
        self.srv = socket.create_server(('127.0.0.1', port))

    def run(self):
        try:
            conn, _ = self.srv.accept()
            conn.close()
        except Exception:
            pass


def run_client(port, extra=None, timeout=15):
    cmd = [PY, CLIENT, '--host', '127.0.0.1', '--port', str(port),
           '--server-name', '192.168.110.115',
           '--ca', os.path.join(CERTS, 'ca.pem'),
           '--cert', os.path.join(CERTS, 'client.pem'),
           '--key', os.path.join(CERTS, 'client.key')]
    if extra:
        cmd += extra
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    accepted = (r.returncode == 0 and 'PASS' in r.stdout)
    return accepted, r.returncode, r.stdout.strip(), r.stderr.strip()


def record(scn_id, name, accepted, exit_code, out, err, tls_occurred, server_exit=None, expect_accept=False):
    # 拒绝场景 expect_accept=False：被拒绝=PASS；happy path expect_accept=True：被接受=PASS
    verdict = 'PASS' if (accepted == expect_accept) else 'FAIL'
    rec = {'id': scn_id, 'name': name, 'client_accepted': accepted,
           'expect_accept': expect_accept, 'reject_control': verdict,
           'client_exit_code': exit_code,
           'tls_handshake_occurred': tls_occurred,
           'server_exit_code': server_exit,
           'client_stdout': out, 'client_stderr': err}
    with open(os.path.join(OUTDIR, scn_id + '.json'), 'w') as f:
        json.dump(rec, f, indent=2, ensure_ascii=False)
    return rec


def main():
    if not CERTS or not os.path.isdir(CERTS):
        print('SKIP: FV006_CERTS_DIR not set or missing (need server.key).')
        sys.exit(0)
    results = []

    # HAPPY
    port = free_port()
    srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port)
        results.append(record('HAPPY', '正常 mTLS + 正确回执', acc, rc, out, err, True, reap(srv), expect_accept=True))
    except Exception as e:
        results.append(('HAPPY', 'ERROR ' + traceback.format_exc()))
    finally:
        srv.terminate()

    # R01 错误 CA
    port = free_port(); srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port, extra=['--ca', os.path.join(CERTS, 'rogue_ca.pem')])
        results.append((record('R01', '错误 CA', acc, rc, out, err, False, reap(srv))))
    finally:
        srv.terminate()

    # R02 过期客户端证书
    port = free_port(); srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port, extra=['--cert', os.path.join(CERTS, 'expired_client.pem'), '--key', os.path.join(CERTS, 'expired_client.key')])
        results.append((record('R02', '过期客户端证书', acc, rc, out, err, True, reap(srv))))
    finally:
        srv.terminate()

    # R03 客户端证书/私钥不匹配
    port = free_port(); srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port, extra=['--key', os.path.join(CERTS, 'rogue_client.key')])
        results.append((record('R03', '客户端证书/私钥不匹配', acc, rc, out, err, False, reap(srv))))
    finally:
        srv.terminate()

    # R04 错误主机名
    port = free_port(); srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port, extra=['--server-name', 'wrong.host'])
        results.append((record('R04', '错误服务端主机名', acc, rc, out, err, False, reap(srv))))
    finally:
        srv.terminate()

    # R05 缺少客户端证书
    port = free_port(); srv = start_real_server(port)
    try:
        cmd = [PY, CLIENT, '--host', '127.0.0.1', '--port', str(port),
               '--server-name', '192.168.110.115', '--ca', os.path.join(CERTS, 'ca.pem')]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=15)
        acc = (r.returncode == 0)
        results.append((record('R05', '缺少客户端证书', acc, r.returncode, r.stdout.strip(), r.stderr.strip(), True, reap(srv))))
    finally:
        srv.terminate()

    # R06 缺少/无效 CA
    port = free_port(); srv = start_real_server(port)
    try:
        acc, rc, out, err = run_client(port, extra=['--ca', os.path.join(CERTS, 'client.pem')])
        results.append((record('R06', '缺少/无效 CA（使用终端实体证书作 CA）', acc, rc, out, err, False, reap(srv))))
    finally:
        srv.terminate()

    # R07 服务端证书/私钥不匹配
    port = free_port()
    srv = start_real_server(port, key=os.path.join(CERTS, 'client.key'))
    time.sleep(0.6)
    acc, rc, out, err = run_client(port)
    try:
        se = reap(srv)
    except Exception:
        se = None
    results.append(record('R07', '服务端证书/私钥不匹配', acc, rc, out, err, False, se))
    srv.terminate()

    # R08 非法 JSON 回执（篡改服务端发送非 JSON）
    port = free_port(); ts = TamperServer(port, 'this is not valid json'); ts.start(); time.sleep(0.5)
    acc, rc, out, err = run_client(port)
    results.append((record('R08', '非法 JSON 回执', acc, rc, out, err, True)))

    # R09 非法 ack 回执（保留 request_id，仅改 ack）
    port = free_port(); ts = TamperServer(port, {"request_id": "x", "node_id": "server", "ack": "REJECTED"}); ts.start(); time.sleep(0.5)
    acc, rc, out, err = run_client(port)
    results.append((record('R09', '非法 ack 回执', acc, rc, out, err, True)))

    # R10 篡改 request_id 回执（故意不回显，伪造 request_id）
    port = free_port(); ts = TamperServer(port, {"request_id": "TAMPERED", "node_id": "server", "ack": "ACCEPTED"}, echo_request_id=False); ts.start(); time.sleep(0.5)
    acc, rc, out, err = run_client(port)
    results.append((record('R10', '篡改 request_id 回执', acc, rc, out, err, True)))

    # R11 篡改 node_id 回执（修复点：必须拒绝；保留 request_id 以精确锁定 node_id）
    port = free_port(); ts = TamperServer(port, {"request_id": "x", "node_id": "ATTACKER_IMPERSONATOR", "ack": "ACCEPTED"}); ts.start(); time.sleep(0.5)
    acc, rc, out, err = run_client(port)
    results.append((record('R11', '篡改 node_id 回执（F-C 修复点）', acc, rc, out, err, True)))

    # R12 服务端停止（不启动）
    port = free_port()
    acc, rc, out, err = run_client(port)
    results.append((record('R12', '服务端停止', acc, rc, out, err, False)))

    # R13 端口关闭（同 R12，独立端口）
    port = free_port()
    acc, rc, out, err = run_client(port)
    results.append((record('R13', '端口关闭', acc, rc, out, err, False)))

    # R14 无响应/超时
    port = free_port(); hs = HangServer(port); hs.start(); time.sleep(0.3)
    acc, rc, out, err = run_client(port)
    results.append((record('R14', '无响应/超时', acc, rc, out, err, True)))

    # R15 对端不可达
    port = free_port()
    acc, rc, out, err = run_client(port, extra=['--host', '192.0.2.1'])
    results.append((record('R15', '对端不可达 (TEST-NET)', acc, rc, out, err, False)))

    # 汇总
    summ = {'generated_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
            'scenario_count': len(results), 'pass': 0, 'fail': 0, 'results': []}
    for r in results:
        if isinstance(r, tuple) and len(r) == 2 and r[0] == 'HAPPY':
            print('HAPPY', 'ERROR')
            summ['results'].append({'id': 'HAPPY', 'error': r[1]})
            continue
        rid = r['id']; name = r['name']; accepted = r['client_accepted']; verdict = r['reject_control']
        if verdict == 'PASS':
            summ['pass'] += 1
        else:
            summ['fail'] += 1
        print(f"{rid:6} {verdict:4} accepted={accepted} {name}")
        summ['results'].append({'id': rid, 'name': name, 'verdict': verdict})
    with open(os.path.join(OUTDIR, 'SUMMARY.json'), 'w') as f:
        json.dump(summ, f, indent=2, ensure_ascii=False)
    print(f"\nSUMMARY pass={summ['pass']} fail={summ['fail']} total={summ['scenario_count']}")
    sys.exit(0 if summ['fail'] == 0 else 1)


if __name__ == '__main__':
    main()
