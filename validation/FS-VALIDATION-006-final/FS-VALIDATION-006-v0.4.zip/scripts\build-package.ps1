param([string]$Output = 'C:\obs-verify-evidence-hbg\fv006v04\FS-VALIDATION-006-v0.4.zip')
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$stage = Join-Path ([IO.Path]::GetTempPath()) ('fv006v04-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Force $stage | Out-Null
# 显式文件清单：仅源码与文档，绝不包含 *.pem / *.key / __pycache__ / results / .git
$files = @(
    'README.md',
    'VALIDATION-MANIFEST.yml',
    'PROTOCOL.md',
    'server/server.py',
    'client/client.py',
    'tests/test_validation.py',
    'tests/test_reject_suite.py',
    'tests/test_static.py',
    'scripts/build-package.ps1'
)
foreach ($f in $files) {
    $t = Join-Path $stage $f
    New-Item -ItemType Directory -Force (Split-Path $t) | Out-Null
    Copy-Item (Join-Path $root $f) $t -Force
}
# 卫生检查：打包目录不得出现私钥/证书/编译产物
$bad = Get-ChildItem -Path $stage -Recurse -File | Where-Object {
    $_.Extension -in @('.pem', '.key') -or $_.Name -eq 'server.key' -or $_.DirectoryName.Contains('__pycache__')
}
if ($bad) { Write-Error "PACKAGE HYGIENE FAIL: found forbidden files: $($bad.FullName)"; exit 1 }
New-Item -ItemType Directory -Force (Split-Path $Output) | Out-Null
if (Test-Path $Output) { Remove-Item $Output -Force }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $Output -CompressionLevel Optimal
Get-FileHash -Algorithm SHA256 $Output
